import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF2B8A3E); // verde
const kSecondaryColor = Color(0xFFFFE1B3); // galben (pentru rating)
const kTextColor = Color(0xFF222222);