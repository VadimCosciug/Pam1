import 'package:flutter/material.dart';

void main() {
  runApp(const TemperatureConverterApp());
}

class TemperatureConverterApp extends StatelessWidget {
  const TemperatureConverterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Conversie Temperatură',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const TemperatureConverterPage(),
    );
  }
}

class TemperatureConverterPage extends StatefulWidget {
  const TemperatureConverterPage({super.key});

  @override
  State<TemperatureConverterPage> createState() => _TemperatureConverterPageState();
}

class _TemperatureConverterPageState extends State<TemperatureConverterPage> {
  final TextEditingController _temperatureController = TextEditingController();
  String _sourceUnit = 'Celsius';
  String _destinationUnit = 'Fahrenheit';
  String _result = '';
  bool _isConverting = false;

  // Temperature conversion functions
  double _celsiusToFahrenheit(double celsius) {
    return (celsius * 9 / 5) + 32;
  }

  double _fahrenheitToCelsius(double fahrenheit) {
    return (fahrenheit - 32) * 5 / 9;
  }

  double _celsiusToKelvin(double celsius) {
    return celsius + 273.15;
  }

  double _kelvinToCelsius(double kelvin) {
    return kelvin - 273.15;
  }

  double _fahrenheitToKelvin(double fahrenheit) {
    return _celsiusToKelvin(_fahrenheitToCelsius(fahrenheit));
  }

  double _kelvinToFahrenheit(double kelvin) {
    return _celsiusToFahrenheit(_kelvinToCelsius(kelvin));
  }

  void _convertTemperature() {
    if (_temperatureController.text.isEmpty) {
      setState(() {
        _result = 'Vă rugăm să introduceți o temperatură';
      });
      return;
    }

    setState(() {
      _isConverting = true;
    });

    try {
      double inputTemperature = double.parse(_temperatureController.text);
      double convertedTemperature;

      // Convert based on source and destination units
      if (_sourceUnit == _destinationUnit) {
        convertedTemperature = inputTemperature;
      } else if (_sourceUnit == 'Celsius' && _destinationUnit == 'Fahrenheit') {
        convertedTemperature = _celsiusToFahrenheit(inputTemperature);
      } else if (_sourceUnit == 'Celsius' && _destinationUnit == 'Kelvin') {
        convertedTemperature = _celsiusToKelvin(inputTemperature);
      } else if (_sourceUnit == 'Fahrenheit' && _destinationUnit == 'Celsius') {
        convertedTemperature = _fahrenheitToCelsius(inputTemperature);
      } else if (_sourceUnit == 'Fahrenheit' && _destinationUnit == 'Kelvin') {
        convertedTemperature = _fahrenheitToKelvin(inputTemperature);
      } else if (_sourceUnit == 'Kelvin' && _destinationUnit == 'Celsius') {
        convertedTemperature = _kelvinToCelsius(inputTemperature);
      } else if (_sourceUnit == 'Kelvin' && _destinationUnit == 'Fahrenheit') {
        convertedTemperature = _kelvinToFahrenheit(inputTemperature);
      } else {
        convertedTemperature = inputTemperature;
      }

      setState(() {
        _result = '${convertedTemperature.toStringAsFixed(2)}° ${_destinationUnit[0]}';
        _isConverting = false;
      });
    } catch (e) {
      setState(() {
        _result = 'Vă rugăm să introduceți un număr valid';
        _isConverting = false;
      });
    }
  }

  @override
  void dispose() {
    _temperatureController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: const Text('Conversie Temperatură'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Input section
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Introduceți temperatura:',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _temperatureController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        hintText: 'Ex: 25',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.thermostat),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Source unit selection
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Unitatea sursă:',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: RadioListTile<String>(
                            title: const Text('Celsius'),
                            value: 'Celsius',
                            groupValue: _sourceUnit,
                            onChanged: (String? value) {
                              setState(() {
                                _sourceUnit = value!;
                              });
                            },
                          ),
                        ),
                        Expanded(
                          child: RadioListTile<String>(
                            title: const Text('Fahrenheit'),
                            value: 'Fahrenheit',
                            groupValue: _sourceUnit,
                            onChanged: (String? value) {
                              setState(() {
                                _sourceUnit = value!;
                              });
                            },
                          ),
                        ),
                        Expanded(
                          child: RadioListTile<String>(
                            title: const Text('Kelvin'),
                            value: 'Kelvin',
                            groupValue: _sourceUnit,
                            onChanged: (String? value) {
                              setState(() {
                                _sourceUnit = value!;
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Destination unit selection
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Unitatea destinație:',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: RadioListTile<String>(
                            title: const Text('Celsius'),
                            value: 'Celsius',
                            groupValue: _destinationUnit,
                            onChanged: (String? value) {
                              setState(() {
                                _destinationUnit = value!;
                              });
                            },
                          ),
                        ),
                        Expanded(
                          child: RadioListTile<String>(
                            title: const Text('Fahrenheit'),
                            value: 'Fahrenheit',
                            groupValue: _destinationUnit,
                            onChanged: (String? value) {
                              setState(() {
                                _destinationUnit = value!;
                              });
                            },
                          ),
                        ),
                        Expanded(
                          child: RadioListTile<String>(
                            title: const Text('Kelvin'),
                            value: 'Kelvin',
                            groupValue: _destinationUnit,
                            onChanged: (String? value) {
                              setState(() {
                                _destinationUnit = value!;
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Convert button
            ElevatedButton(
              onPressed: _isConverting ? null : _convertTemperature,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor: Theme.of(context).colorScheme.primary,
                foregroundColor: Theme.of(context).colorScheme.onPrimary,
              ),
              child: _isConverting
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    )
                  : const Text(
                      'CONVERTEȘTE',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
            ),
            const SizedBox(height: 20),

            // Result display
            if (_result.isNotEmpty)
              Card(
                color: Theme.of(context).colorScheme.primaryContainer,
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      const Text(
                        'Rezultat:',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        _result,
                        style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).colorScheme.onPrimaryContainer,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}